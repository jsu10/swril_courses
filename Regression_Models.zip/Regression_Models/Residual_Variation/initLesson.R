galton <- read.csv(file.path(find.package("swirl"), "Courses/Regression_Models/Introduction", "galton.csv"))
n <- 928
